--------------------
Extra: gitHubDocs
--------------------
Version: 1.0.0-pl
Released: November 27, 2018
Since: November 15, 2018

A GitHub markdown documentation Extra for MODX Revolution.

#### Documentation
- Official Documentation: TBC
- GitHub Repository: http://github.com/tasianmedia/githubdocs
- Bugs & Feature Requests: http://github.com/tasianmedia/githubdocs/issues

#### Details
Author: David Pede <dev@tasian.media>
Copyright: (C) 2018 Tasian Media. All rights reserved. <studio@tasian.media>

#### Please Note
gitHubDocs is not associated with or endorsed by GitHub Inc.

#### License
Released under the GNU General Public License; either version 2 of the License, or (at your option) any later version.
http://www.gnu.org/licenses/gpl.html
